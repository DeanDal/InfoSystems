--List of each task of each professor for a selected
--semester also giving the total work load balance
--(Stundenkontostand – accumulated real work load
--versus required work load (Deputat))

SELECT subject_name, SUM(C.hour) AS totalWorkLoadBalance
FROM course C INNER JOIN subject S ON C.subject_Id = S.subject_Id
			  INNER JOIN hassubject H ON S.subject_Id = H.subject_Id
			  INNER JOIN course_semester CS ON H.course_semester_Id = CS.course_semester_Id
			  INNER JOIN give G ON CS.course_semester_Id = G.course_semester_Id
			  INNER JOIN lecturer L ON G.lecturer_Id = L.lecturer_Id
WHERE CS.course_semester_id = 1
GROUP BY L.lecturer_Id, subject_name
ORDER BY subject_name ASC;

--List of module elements offered in a selected
--academic half year for a selected degree
--(Studiengang)

SELECT subject_name
FROM course C INNER JOIN subject S ON C.subject_Id = S.subject_Id
			  INNER JOIN hassubject H ON S.subject_Id = H.subject_Id
			  INNER JOIN course_semester CS ON H.course_semester_Id = CS.course_semester_Id
WHERE CS.course_semester_id = 1
ORDER BY subject_name ASC;

--List of external lecturers, their SWS for a selected
--academic half year and their addresses

SELECT first_name, last_name, C.city_name 
FROM lecturer L INNER JOIN city C ON L.city_Id = C.city_Id
				INNER JOIN give G ON L.lecturer_Id = G.lecturer_Id
				INNER JOIN course_semester CS ON G.course_semester_Id = CS.course_semester_Id
WHERE CS.course_semester_id = 1
ORDER BY last_name ASC;

--List of services provided, i.e. list of module elements
--taught by IT professors for a different department
--(name of module element, name of the lecturer,
--SWS, department which the service is provided for)

